def main(x):
    if (x == 1):
        return 1
    elif x == 2:
        return 2
    else:
        return 0


def expected_result():
    return [0, 1, 2]
