def main(x):
    y = x > 1
    if y:
        return 1
    else:
        return 0
    return y

def expected_result():
    return [0, 1]
