def main(x):
    if (x==2):
        return -(x==2)
    else:
        return 0

def expected_result():
    return [-1,0]
