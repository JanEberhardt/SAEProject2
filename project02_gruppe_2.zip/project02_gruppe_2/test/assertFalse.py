def main(x):
    assert False
    return 1

def expected_result():
    return [1]
