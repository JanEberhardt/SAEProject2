def main(x):
    if x == 1:
        return 2
    return 1

def expected_result():
    return [2, 1]
