def main(x):
    if 1 == 1:
        return 1
    else:
        assert(x > 1)
        return 0


def expected_result():
    return [1]
