def main(x, y):
    if (x==0) and (y==0):
        return x+y
    else:
        return 1

def expected_result():
    return [0,1]
