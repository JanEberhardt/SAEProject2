def biggerZero(y):
    if y>1:
        return 1
    else:
        return 0

def main(x):
    return biggerZero(x)

def expected_result():
    return [1,0]
