def main(x):
    if x != 0:
        return 1
    else:
        return 0

def expected_result():
    return [1, 0]
