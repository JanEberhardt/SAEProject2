def main(x,y):
    if (x<y) + x == 5:
        return 0
    else:
        return 1

def expected_result():
    return [0,1]
