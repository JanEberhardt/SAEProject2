def main(x):
    x = 2 * x
    assert x % 2 == 0
    return 0

def expected_result():
    return [0]
