##there should be 2 return paths for 2
def main(x, y):
    if (x==2) == (y==2):
        return 2
    return 1

def expected_result():
   return [2, 1]
