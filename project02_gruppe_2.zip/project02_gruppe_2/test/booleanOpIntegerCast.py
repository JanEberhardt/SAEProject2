def main(x):
    if x and True:
        return 0
    else:
        return 1

def expected_result():
    return [0,1]
