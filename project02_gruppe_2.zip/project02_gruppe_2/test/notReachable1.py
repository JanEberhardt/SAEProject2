def main(x):
    y = 1
    if y == 0:
        assert False
    else:
        return y

def expected_result():
    return [1]
