def main(x):
    return 1

def expected_result():
    return [1]
