def main(x):
    a = x + 1
