def main(x):
    assert x<0
    return 1

def expected_result():
    return [1]
