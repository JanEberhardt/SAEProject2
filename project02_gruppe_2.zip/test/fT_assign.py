def main(x):
    a = 1
    return a

def expected_result():
    return [1]
