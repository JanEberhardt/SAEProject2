def main(x):
    if x == True:
        return 1
    else:
        return 0

def expected_result():
    return [0,1]
