def main(x):
    return x > 1

def expected_result():
    return [False]
