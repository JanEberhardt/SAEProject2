def main(x):
    (a, b) = (10, x)
    if b == 1:
        return 1
    else:
        return 20

def expected_result():
    return [1, 20]
