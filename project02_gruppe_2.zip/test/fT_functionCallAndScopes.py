def abs(a):
    x = 2
    if x != 2:
        return 100
    if a<0:
        return -a
    else:
        return a

def main(x):
    return abs(x)

def expected_result():
    return [0,1]
