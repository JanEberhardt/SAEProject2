def main(x):
    a = -x
    if(a<0):
        return -1
    else:
        return 1

def expected_result():
    return [-1,1]
