def main(a):
    assert(a < 0)
    return 0

def expected_result():
    return [0]
