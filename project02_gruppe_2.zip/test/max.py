def main (x , y ):
    if ( x > y ):
        return 1
    elif ( x < y ):
        return -1
    else :
        return 0

def expected_result():
    return [ -1 ,0 ,1]