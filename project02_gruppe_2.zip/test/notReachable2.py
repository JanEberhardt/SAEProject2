def main(x,y):
    return 1
    a = x + y

def expected_result():
    return [1]
