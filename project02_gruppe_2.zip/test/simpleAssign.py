def main(x, y):
	x = y
	return x

def expected_result():
    return [0]
