def main(a, b, c):
    return -1

def expected_result():
    return [-1]
