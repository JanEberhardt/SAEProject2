def main(x):
    return 10
    return 20
    return 30

def expected_result():
    return [10]
