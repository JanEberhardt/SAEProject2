def main ( x ):
    x = x * x
    if x < 0:
        return 0
    else :
        return 1

def expected_result():
    return [1]
