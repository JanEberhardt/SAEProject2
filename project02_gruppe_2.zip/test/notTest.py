def main(x):
    a = 3
    return not(a<0)

def expected_result():
    return [True]
