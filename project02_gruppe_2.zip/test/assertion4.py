def main(x):
    assert(twice(x) == x + 1)
    return 1


def twice(x):
    return 2*x


def expected_result():
    return [1]
