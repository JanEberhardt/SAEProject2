def main(x):
    assert(False)
    if (x>10):
        return 1;
    else:
        return 2

def expected_result():
    return [1,2]
