def main(x,y,z):
    return -(x<0 and y<0 and z<0)

def expected_result():
    return [0]
