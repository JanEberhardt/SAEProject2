def main(x, y):
    if -(x == y) == -1:
        return 1
    else:
        return 0

def expected_result():
    return [0,1]
