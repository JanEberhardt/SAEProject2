def main(x):
    a = 1
    assert a == 1
    assert a < 1
    assert a != 1
    return 1

def expected_result():
    return [1]
