def main(x):
    if (x!=0) + (x<=0) == 2:
        return 1
    else:
        return 0

def expected_result():
    return [0,1]

