def main(x):
    assert(twice(x) == 2*x)
    return 1


def twice(x):
    return 2*x


def expected_result():
    return [1]
