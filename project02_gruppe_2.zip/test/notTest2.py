def main(x):
    if (not x<3) == 1:
        return 1
    else:
        return 0

def expected_result():
    return [1,0]
